import random
from flask import Flask, render_template, flash, session, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

from flask_bcrypt import Bcrypt 
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
bcrypt = Bcrypt(app)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(basedir, "app.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)

    def _repr_(self):
        return f"User('{self.username}')"

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Integer, nullable=False)

    def _repr_(self):
        return f"Product('{self.name}', '{self.price}')"
with app.app_context():
    db.create_all()
    
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
    

@app.route('/')
def homepage():
    return render_template('index.html')
@app.route('/home')
def home():
    
    if 'username' not in session:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('login'))
    
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('homepage'))  

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash('Login Successful!', 'success')

            
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('homepage'))
        
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')

    return render_template('login.html')



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('homepage'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('signup'))
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists', 'danger')
            return redirect(url_for('signup'))
        
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! Please login', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')



@app.route('/logout')
def logout():
    logout_user()
    flash("You are logged out")
    return redirect(url_for('login'))


@app.route('/aboutus')  
def about_us():
    return render_template('aboutus.html')


@app.route('/profile')
@login_required 
def my_account():
    return render_template('profile.html')


@app.route('/remove_item')


@app.route('/product_cart')

@app.route('/haircare')
def haircare_page():
    haircare_products = [
        {"name": "Shampoo", "price": "RS.500", "image": "shampoo.jpg"},
        {"name": "Conditioner", "price": "RS.600", "image": "conditioner.jpg"},
        {"name": "Hair Serum", "price": "RS.1200", "image": "hair_serum.webp"},
        {"name": "Hair Mask", "price": "RS.1000", "image": "hair_mask.jpg"},
        {"name": "Leave-in Conditioner", "price": "RS.700", "image": "leave_in_conditioner.webp"},
        {"name": "Hair Oil", "price": "RS.800", "image": "hair_oil.jpg"},
        {"name": "Dry Shampoo", "price": "RS.400", "image": "dry_shampoo.webp"},
        {"name": "Hair Mousse", "price": "RS.650", "image": "hair_mousse.jpg"},
        {"name": "Volumizing Spray", "price": "RS.900", "image": "volumizing_spray.jpg"},
        {"name": "Hair Straightener", "price": "RS.3000", "image": "hair_straightener.jpg"}
    ]
    return render_template('haircare.html', products=haircare_products)


@app.route('/makeup')
def makeup_page():
    makeup_products = [
        {"name": "Foundation", "price": "RS.2000", "image": "foundation.webp"},
        {"name": "Lipstick", "price": "RS.500", "image": "lipstick.jpg"},
        {"name": "Mascara", "price": "RS.800", "image": "mascara.jpg"},
        {"name": "Blush", "price": "RS.600", "image": "blush.jpg"},
        {"name": "Eyeshadow Palette", "price": "RS.1500", "image": "eyeshadow_palette.jpg"},
        {"name": "Highlighter", "price": "RS.1000", "image": "highlighter.jpg"},
        {"name": "Eyebrow Pencil", "price": "RS.400", "image": "eyebrow_pencil.jpg"},
        {"name": "Lip Gloss", "price": "RS.700", "image": "lip_gloss.webp"},
        {"name": "Primer", "price": "RS.900", "image": "primer.jpg"},
        {"name": "Setting Spray", "price": "RS.950", "image": "setting_spray.webp"}
    ]
    return render_template('makeup.html', products=makeup_products)


@app.route('/skincare')
def skincare_page():
    skincare_products = [
        {"name": "Face Cream", "price": "RS.1500", "image": "facecream.webp"},
        {"name": "Serum", "price": "RS.1000", "image": "serum.webp"},
        {"name": "Cleanser", "price": "RS.500", "image": "cleanser.jpg"},
        {"name": "Moisturizer", "price": "RS.700", "image": "moisturizer.webp"},
        {"name": "HydraGlow Moisturizer", "price": "RS.1200", "image": "hydra_glow_moisturizer.jpg"},
        {"name": "Brightening Vitamin C Serum", "price": "RS.1500", "image": "vitamin_c_serum.avif"},
        {"name": "Anti-Aging Night Cream", "price": "RS.1800", "image": "anti_aging_night_cream.jpg"},
        {"name": "Green Tea Face Mask", "price": "RS.950", "image": "green_tea_face_mask.jpg"},
        {"name": "Aloe Vera Gel", "price": "RS.500", "image": "aloe_vera_gel..webp"},
        {"name": "Exfoliating Scrub", "price": "RS.700", "image": "scrub.avif"},
         
    {"name": "Sunscreen SPF 50", "price": "RS.1300", "image":"sunscreen.webp"},
    {"name": "Charcoal Peel-Off Mask", "price": "RS.900", "image": "charcoal_mask.jpeg"},
    {"name": "Hyaluronic Acid Serum", "price": "RS.1600", "image": "hyaluronic_acid_serum.webp"},
    {"name": "Retinol Night Serum", "price": "RS.1700", "image": "retinol_serum.jpeg"},
    {"name": "Rose Water Toner", "price": "RS.600", "image": "rose_water_toner..webp"},
    {"name": "Collagen Boosting Cream", "price": "RS.1900", "image": "collagen_cream.webp"},
    {"name": "Tea Tree Oil Face Wash", "price": "RS.750", "image": "tea_tree_facewash.jpeg"},
    {"name": "Under Eye Cream", "price": "RS.1100", "image": "under_eye.jpeg"},
    {"name": "Niacinamide Serum", "price": "RS.1400", "image": "niacinamide_serum.jpg"},
    {"name": "Clay Face Mask", "price": "RS.850", "image": "clay_face_mask.jpeg"},
]




        
        
        
    
    return render_template('skincare.html', products=skincare_products)


@app.route('/shop')
def shop_page():
    all_products = [
        {"name": "Shampoo", "price": "RS.500", "image": "shampoo.jpg"},
        {"name": "Conditioner", "price": "RS.600", "image": "conditioner.jpg"},
        {"name": "Hair Serum", "price": "RS.1200", "image": "hair_serum.webp"},
        {"name": "Hair Mask", "price": "RS.1000", "image": "hair_mask.jpg"},
        {"name": "Leave-in Conditioner", "price": "RS.700", "image": "leave_in_conditioner.webp"},
        {"name": "Hair Oil", "price": "RS.800", "image": "hair_oil.jpg"},
        {"name": "Dry Shampoo", "price": "RS.400", "image": "dry_shampoo.webp"},
        {"name": "Hair Mousse", "price": "RS.650", "image": "hair_mousse.jpg"},
        {"name": "Volumizing Spray", "price": "RS.900", "image": "volumizing_spray.jpg"},
        {"name": "Hair Straightener", "price": "RS.3000", "image": "hair_straightener.jpg"},
        {"name": "Foundation", "price": "RS.2000", "image": "foundation.webp"},
        {"name": "Lipstick", "price": "RS.500", "image": "lipstick.jpg"},
        {"name": "Mascara", "price": "RS.800", "image": "mascara.jpg"},
        {"name": "Blush", "price": "RS.600", "image": "blush.jpg"},
        {"name": "Eyeshadow Palette", "price": "RS.1500", "image": "eyeshadow_palette.jpg"},
        {"name": "Highlighter", "price": "RS.1000", "image": "highlighter.jpg"},
        {"name": "Eyebrow Pencil", "price": "RS.400", "image": "eyebrow_pencil.jpg"},
        {"name": "Lip Gloss", "price": "RS.700", "image": "lip_gloss.webp"},
        {"name": "Primer", "price": "RS.900", "image": "primer.jpg"},
        {"name": "Setting Spray", "price": "RS.950", "image": "setting_spray.webp"},
        {"name": "Face Cream", "price": "RS.1500", "image": "facecream.webp"},
        {"name": "Serum", "price": "RS.1000", "image": "serum.webp"},
        {"name": "Cleanser", "price": "RS.500", "image": "cleanser.jpg"},
        {"name": "Moisturizer", "price": "RS.700", "image": "moisturizer.webp"},
        {"name": "HydraGlow Moisturizer", "price": "RS.1200", "image": "hydra_glow_moisturizer.jpg"},
        {"name": "Brightening Vitamin C Serum", "price": "RS.1500", "image": "vitamin_c_serum.avif"},
        {"name": "Anti-Aging Night Cream", "price": "RS.1800", "image": "anti_aging_night_cream.jpg"},
        {"name": "Green Tea Face Mask", "price": "RS.950", "image": "green_tea_face_mask.jpg"},
        {"name": "Aloe Vera Gel", "price": "RS.500", "image": "aloe_vera_gel..webp"},
        {"name": "Exfoliating Scrub", "price": "RS.700", "image": "scrub.avif"}
    ]
    random.shuffle(all_products)
    return render_template('shop.html', products=all_products)

@app.route('/submit',methods=['POST'])
def submit():
    product_name = request.form.get('product_name')
    price_str = request.form.get('price')
    
    try:
        price = int(price_str.replace('RS.', '').strip())
    except:
        flash('Invalid price format', 'error')
        return redirect(url_for('homepage'))
    cart = session.get('cart', {})
    if product_name in cart:
        cart[product_name]['quantity'] += 1
    else:
        cart[product_name] = {'price': price, 'quantity': 1}
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    cart = session.get('cart', {})
    items = []
    total = 0
    item_count = 0
    for product_name, details in cart.items():
        item_total = details['price'] * details['quantity']
        items.append({
            'name': product_name,
            'price': details['price'],
            'quantity': details['quantity'],
            'total': item_total
        })
        total += item_total
        item_count += details['quantity']
   
    return render_template('cart.html', cart={'cart_items': items, 'total': total, 'item_count': item_count})

@app.route('/update_cart/<product_name>', methods=['POST'])
def update_cart(product_name):
    new_quantity = int(request.form.get('quantity', 1))
    cart = session.get('cart', {})
    if product_name in cart:
        if new_quantity < 1:
            del cart[product_name]
        else:
            cart[product_name]['quantity'] = new_quantity
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/remove_item/<product_name>')
def remove_item(product_name):
    cart = session.get('cart', {})
    if product_name in cart:
        del cart[product_name]
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/checkout')
def checkout():
   
    cart_data = {
        "items": session.get('cart', {}),
        "total": sum(item['price'] * item['quantity'] for item in session.get('cart', {}).values()),
        "item_count": sum(item['quantity'] for item in session.get('cart', {}).values())
    }
    return render_template('checkout.html', cart=cart_data)


@app.route('/order',methods=['GET', 'POST'])
def order():
    return render_template('order_successful.html')














   


if __name__ == '__main__':
    app.run(debug=True)